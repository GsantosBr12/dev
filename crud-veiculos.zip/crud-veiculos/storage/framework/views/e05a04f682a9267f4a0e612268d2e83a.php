<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veiculos</title>
</head>
<body>
    <?php if(Auth::check()): ?>
        <a href="/logout">Sair</a>
        <hr>
    <?php endif; ?>

    <?php echo $__env->yieldContent('conteudo'); ?>
</body>
</html><?php /**PATH H:\www\crud-veiculos\crud-veiculos\resources\views/layouts/app.blade.php ENDPATH**/ ?>