

<?php $__env->startSection('conteudo'); ?>
<div>
    <h2>Crud veiculos</h2>
    <a href="/create">Criar Novo</a>
</div>
<table>
        <thead>
            <tr>
                <th>Nome do Veículo</th>
                <th>Marca</th>
                <th>Ano</th>
                <th>Preço</th>
                <th>Qualidade</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($veiculo->nome_do_veiculo); ?></td>
                    <td><?php echo e($veiculo->marca); ?></td>
                    <td><?php echo e($veiculo->ano); ?></td>
                    <td><?php echo e($veiculo->preco); ?></td>
                    <td><?php echo e($veiculo->qualidade); ?></td>
                    <td>
            <form action="/delete" method="post" id="form-delete-<?php echo e($veiculo->id); ?>">
                <?php echo csrf_field(); ?>                
                <input type="hidden" name="id" value="<?php echo e($veiculo->id); ?>">
                <?php echo method_field('DELETE'); ?>
                <a href="javascript:var c = confirm('Deseja excluir o registro?'); if (c) { document.getElementById('form-delete-<?php echo e($veiculo->id); ?>').submit(); }">Excluir</a>
            </form>
        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\www\crud-veiculos\crud-veiculos\resources\views/index.blade.php ENDPATH**/ ?>