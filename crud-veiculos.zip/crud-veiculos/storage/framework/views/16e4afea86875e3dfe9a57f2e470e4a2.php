<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
</head>
<body>
    <?php echo $__env->yieldContent('conteudo'); ?>
</body>
</html><?php /**PATH C:\Users\usuario\Documents\calculadora-mvc-laravel-3B1\resources\views/layouts/app.blade.php ENDPATH**/ ?>